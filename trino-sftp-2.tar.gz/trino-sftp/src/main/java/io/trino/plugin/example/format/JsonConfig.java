package io.trino.plugin.example.format;

public class JsonConfig
{
}
