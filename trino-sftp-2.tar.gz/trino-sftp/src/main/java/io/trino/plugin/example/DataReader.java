package io.trino.plugin.example;

import java.io.Closeable;

public interface DataReader extends Closeable
{

    String [] read();

    long getCompletedBytes();

    boolean advanceNextPosition();
}
