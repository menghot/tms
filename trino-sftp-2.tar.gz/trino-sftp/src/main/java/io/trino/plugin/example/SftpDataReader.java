package io.trino.plugin.example;

import com.google.common.io.CountingInputStream;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.opencsv.CSVParser;
import com.opencsv.ICSVParser;
import org.openjdk.jol.util.IOUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;

public class SftpDataReader implements DataReader
{

    private final ChannelSftp channel;
    private final CountingInputStream countingInputStream;
    private final BufferedReader reader;
    private String[] fields;
    private boolean ignoreCsvHeader = false;
    private final ICSVParser csvParser = new CSVParser();

    public SftpDataReader(SftpConnectorSplit split) {
        try {
            String host = split.getSftpTable().getSftpConfig().getHost();
            int port = split.getSftpTable().getSftpConfig().getPort();
            String username = split.getSftpTable().getSftpConfig().getUsername();
            String password = split.getSftpTable().getSftpConfig().getPassword();

            // Connect to ssh server and get the session
            Session session = SftpConnectionPool.openOrGetSshSession(host, port, username, password);
            try {
                channel = (ChannelSftp) session.openChannel("sftp");
                channel.connect();
            }
            catch (JSchException e) {
                SftpConnectionPool.removeSession(host + port + username + password);
                throw new RuntimeException(e.getMessage(), e);
            }

            InputStream compressedInputStream = channel.get(split.getUri());
            GZIPInputStream gzipInputStream = new GZIPInputStream(compressedInputStream);
            countingInputStream = new CountingInputStream(gzipInputStream);
            reader = new BufferedReader(new InputStreamReader(countingInputStream));
        }
        catch (SftpException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String[] read()
    {
        return fields;
    }

    @Override
    public long getCompletedBytes()
    {
        return countingInputStream != null ? countingInputStream.getCount() : 0;
    }

    @Override
    public boolean advanceNextPosition()
    {
        if (reader == null) {
            return false;
        }

        String line;
        try {
            line = reader.readLine();
        }
        catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }

        if (line == null) {
            return false;
        }

        if (ignoreCsvHeader) {
            ignoreCsvHeader = false;
            return advanceNextPosition();
        }

        try {
            fields = csvParser.parseLine(line);
        }
        catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }

        return true;
    }

    @Override
    public void close()
    {
        IOUtils.safelyClose(reader);
        IOUtils.safelyClose(countingInputStream);
        if (channel != null) {
            channel.disconnect();
        }
    }
}
