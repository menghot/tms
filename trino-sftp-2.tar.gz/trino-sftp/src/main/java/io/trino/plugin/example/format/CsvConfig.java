package io.trino.plugin.example.format;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import static io.airlift.slice.SizeOf.estimatedSizeOf;
import static io.airlift.slice.SizeOf.instanceSize;

public class CsvConfig
{
    private static final int INSTANCE_SIZE = instanceSize(CsvConfig.class);
    private final boolean ignoreHeader;
    private final String delimiter;
    private char separator;
    private char quotechar;

    @JsonCreator
    public CsvConfig(
            @JsonProperty("ignore_header") boolean ignoreHeader,
            @JsonProperty("delimiter") String delimiter)
    {
        this.ignoreHeader = ignoreHeader;
        this.delimiter = delimiter;
    }

    @JsonProperty
    public boolean isIgnoreHeader()
    {
        return ignoreHeader;
    }

    @JsonProperty
    public String getDelimiter()
    {
        return delimiter;
    }

    public long getRetainedSizeInBytes()
    {
        return INSTANCE_SIZE + estimatedSizeOf(delimiter);
    }
}
