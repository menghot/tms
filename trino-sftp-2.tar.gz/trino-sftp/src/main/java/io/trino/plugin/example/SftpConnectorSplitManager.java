/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.trino.plugin.example;

import com.google.inject.Inject;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import io.trino.spi.connector.ConnectorSession;
import io.trino.spi.connector.ConnectorSplit;
import io.trino.spi.connector.ConnectorSplitManager;
import io.trino.spi.connector.ConnectorSplitSource;
import io.trino.spi.connector.ConnectorTableHandle;
import io.trino.spi.connector.ConnectorTransactionHandle;
import io.trino.spi.connector.Constraint;
import io.trino.spi.connector.DynamicFilter;
import io.trino.spi.connector.FixedSplitSource;
import io.trino.spi.connector.TableNotFoundException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

import static java.util.Objects.requireNonNull;

public class SftpConnectorSplitManager
        implements ConnectorSplitManager
{
    private final SftpMetadataClient sftpMetadataClient;

    @Inject
    public SftpConnectorSplitManager(SftpMetadataClient sftpMetadataClient)
    {
        this.sftpMetadataClient = requireNonNull(sftpMetadataClient, "exampleClient is null");
    }

    @Override
    public ConnectorSplitSource getSplits(
            ConnectorTransactionHandle transaction,
            ConnectorSession session,
            ConnectorTableHandle connectorTableHandle,
            DynamicFilter dynamicFilter,
            Constraint constraint)
    {
        SftpConnectorTableHandle tableHandle = (SftpConnectorTableHandle) connectorTableHandle;
        SftpTable table = sftpMetadataClient.getTable(tableHandle.getSchemaName(), tableHandle.getTableName());

        // this can happen if table is removed during a query
        if (table == null) {
            throw new TableNotFoundException(tableHandle.toSchemaTableName());
        }

        ChannelSftp channel = null;
        List<String> files = new ArrayList<>();
        try {
            Session sftpSession = SftpConnectionPool.openOrGetSshSession(
                    table.getSftpConfig().getHost(),
                    table.getSftpConfig().getPort(),
                    table.getSftpConfig().getUsername(),
                    table.getSftpConfig().getPassword());

            try {
                channel = (ChannelSftp) sftpSession.openChannel("sftp");
                channel.connect();
            }
            catch (JSchException e) {
                SftpConnectionPool.removeSession(table.getSftpConfig().getHost() + table.getSftpConfig().getPort() + table.getSftpConfig().getUsername() + table.getSftpConfig().getPassword());
                throw new RuntimeException(e.getMessage(), e);
            }
            Vector<ChannelSftp.LsEntry> sftpFiles = channel.ls(table.getSftpConfig().getLocation());
            for (ChannelSftp.LsEntry entry : sftpFiles) {
                String fileName = entry.getFilename();

                //TOTO support push down (filter) files

                if (fileName.matches(".*\\.gz$") && !entry.getAttrs().isDir()) {
                    files.add(fileName);
                }
            }
        }
        catch (SftpException e) {
            throw new RuntimeException(e);
        }
        finally {
            if (channel != null) {
                channel.disconnect();
            }
        }

        List<ConnectorSplit> splits = new ArrayList<>();
        for (String file : files) {
            splits.add(new SftpConnectorSplit(table.getSftpConfig().getLocation() + "/" + file, table));
        }
        Collections.shuffle(splits);

        return new FixedSplitSource(splits);
    }
}
