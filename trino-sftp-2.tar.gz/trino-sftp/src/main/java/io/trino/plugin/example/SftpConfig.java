package io.trino.plugin.example;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import static io.airlift.slice.SizeOf.instanceSize;

public class SftpConfig
{
    private static final int INSTANCE_SIZE = instanceSize(SftpConfig.class);

    private final String host;
    private final int port;
    private final String username;
    private final String password;
    private final String location;

    @JsonCreator
    public SftpConfig(
            @JsonProperty("host") String host,
            @JsonProperty("port") int port,
            @JsonProperty("username") String username,
            @JsonProperty("password") String password,
            @JsonProperty("location") String location)
    {
        this.host = host;
        this.port = port;
        this.username = username;
        this.password = password;
        this.location = location;
    }

    @JsonProperty
    public String getHost()
    {
        return host;
    }

    @JsonProperty
    public int getPort()
    {
        return port;
    }

    @JsonProperty
    public String getUsername()
    {
        return username;
    }

    @JsonProperty
    public String getPassword()
    {
        return password;
    }

    @JsonProperty
    public String getLocation()
    {
        return location;
    }

    public long getRetainedSizeInBytes()
    {
        return INSTANCE_SIZE;
    }
}
