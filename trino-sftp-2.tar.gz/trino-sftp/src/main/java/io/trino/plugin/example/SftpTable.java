/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.trino.plugin.example;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableList;
import io.trino.plugin.example.format.CsvConfig;
import io.trino.spi.connector.ColumnMetadata;

import java.util.List;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.isNullOrEmpty;
import static io.airlift.slice.SizeOf.estimatedSizeOf;
import static io.airlift.slice.SizeOf.instanceSize;
import static java.util.Objects.requireNonNull;

public class SftpTable
{
    private static final int INSTANCE_SIZE = instanceSize(SftpTable.class);

    private final String name;

    private final CsvConfig csvConfig;

    private final SftpConfig sftpConfig;

    private final List<SftpColumn> columns;

    @JsonCreator
    public SftpTable(
            @JsonProperty("name") String name,
            @JsonProperty("csv_config") CsvConfig csvConfig,
            @JsonProperty("sftp_config") SftpConfig sftpConfig,
            @JsonProperty("columns") List<SftpColumn> columns)
    {
        checkArgument(!isNullOrEmpty(name), "name is null or is empty");
        this.name = requireNonNull(name, "name is null");
        this.columns = ImmutableList.copyOf(requireNonNull(columns, "columns is null"));

        this.csvConfig = csvConfig;
        this.sftpConfig = sftpConfig;
    }

    @JsonProperty
    public String getName()
    {
        return name;
    }

    @JsonProperty
    public List<SftpColumn> getColumns()
    {
        return columns;
    }

    public List<ColumnMetadata> getColumnsMetadata()
    {
        ImmutableList.Builder<ColumnMetadata> columnsMetadata = ImmutableList.builder();
        for (SftpColumn column : this.columns) {
            columnsMetadata.add(new ColumnMetadata(column.getName(), column.getType()));
        }
        return columnsMetadata.build();
    }

    @JsonProperty
    public SftpConfig getSftpConfig()
    {
        return sftpConfig;
    }

    public long getRetainedSizeInBytes()
    {
        return INSTANCE_SIZE +
                csvConfig.getRetainedSizeInBytes() +
                estimatedSizeOf(columns, SftpColumn::getRetainedSizeInBytes);
    }

    @JsonProperty
    public CsvConfig getCsvConfig()
    {
        return csvConfig;
    }
}
