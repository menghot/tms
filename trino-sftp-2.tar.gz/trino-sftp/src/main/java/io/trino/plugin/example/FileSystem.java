package io.trino.plugin.example;

public interface FileSystem
{
}
