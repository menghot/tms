package io.trino.plugin.example;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import io.airlift.log.Logger;
import io.trino.plugin.example.func.EncryptDecrypt;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SftpConnectionPool
{
    private static final Logger log = Logger.get(SftpConnectionPool.class);

    private static final Map<String, Session> sessionPool = new ConcurrentHashMap<>();

    public static void removeSession(String key)
    {
        sessionPool.remove(key);
    }

    public static Session openOrGetSshSession(String host, int port, String username, String password)
    {

        String key = host + port + username + password;
        Session conn = sessionPool.get(key);
        log.debug("sftp connection size: %s", sessionPool.keySet().size());
        if (conn == null) {
            return sessionPool.computeIfAbsent(key, sessionKey -> {
                try {
                    JSch jsch = new JSch();
                    Session session = jsch.getSession(username, host, port);
                    session.setPassword(EncryptDecrypt.decrypt(password));
                    session.setConfig("StrictHostKeyChecking", "no"); // Disable strit host key checking
                    session.connect();
                    return session;
                }
                catch (JSchException e) {
                    throw new RuntimeException(e);
                }
            });
        }
        else {
            // make sure connection is connected!
            if (!conn.isConnected()) {
                synchronized (conn) {
                    if (!conn.isConnected()) {
                        try {
                            conn.connect();
                        }
                        catch (JSchException e) {
                            // Remove the connection if failed
                            sessionPool.remove(key);
                            throw new RuntimeException(e.getMessage(), e);
                        }
                    }
                }
            }
            return conn;
        }
    }

    static {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> sessionPool.values().iterator().forEachRemaining(Session::disconnect)));
    }
}
